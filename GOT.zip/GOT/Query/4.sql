-- Calcola il valore medio di ogni transazione
SELECT AVG(ImportoTotaleTransazione) ValoreMedio
FROM buildweek1.transazioni_dataset;
-- Trova la quantità totale di prodotti disponibili in magazzino.
SELECT SUM(QuantitaDisponibile) QuantitaTotale
FROM buildweek1.prodotti_dataset;


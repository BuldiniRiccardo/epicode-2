-- Recensioni: media
   SELECT AVG(Rating) 
   FROM ratings_dataset;
